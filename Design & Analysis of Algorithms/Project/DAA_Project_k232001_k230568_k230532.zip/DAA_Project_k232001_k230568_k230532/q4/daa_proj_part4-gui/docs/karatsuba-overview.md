## Karatsuba Algorithm Walkthrough

### File
- `src/algorithms/karatsuba.js`

### Exported API
- `karatsubaAlgorithm(x, y)`  
  Public entry point used by the UI. Accepts two integers (or numeric strings), runs the recursive Karatsuba multiplication, and returns `{ log, result, digits }`.

### Internal Flow
1. **Logging helpers**  
   `log` collects newline-terminated strings. `write()` handles indentation so nested calls are easy to read.

2. **`karatsuba(a, b, depth)`**  
   - Converts operands to strings and logs the call with indentation based on `depth`.  
   - **Base case**: if either string length is 1, multiply directly with `BigInt` and return.  
   - **Padding**: left-pads both strings so they share the same length.  
   - **Split**: cut each operand into high/low halves (`aHigh`, `aLow`, `bHigh`, `bLow`).  
   - **Recursive multiplications**:  
     - `ac = karatsuba(aHigh, bHigh)`  
     - `bd = karatsuba(aLow, bLow)`  
     - `abCd = karatsuba(aHigh + aLow, bHigh + bLow)` (this equals `ac + ad + bc + bd`).  
   - **Cross terms**: `adPlusBc = abCd - ac - bd`.  
   - **Combine**:  
     ```
     result = ac * 10^(2*half) + adPlusBc * 10^half + bd
     ```
     (powers handled with `BigInt` exponentiation).  
   - Logs each stage to keep the trace readable.

3. **Return structure**  
   After recursion finishes, `karatsubaAlgorithm` logs separators/final stats and returns the joined log, the numeric result as a string, and its digit count.

### Mental Model
Karatsuba reduces the number of recursive multiplications from 4 to 3 by reusing the term `(aHigh + aLow) * (bHigh + bLow)`. This implementation mirrors the textbook algorithm while keeping the logging explicit so the UI can show every split, multiply, and recombination step.

