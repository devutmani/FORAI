import React, { useState } from 'react'
import './App.css'
import ClosestPairTab from './components/ClosestPairTab'
import KaratsubaTab from './components/KaratsubaTab'

export default function App() {
  const [activeTab, setActiveTab] = useState('closest')

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Divide & Conquer Visualizer</h1>
        <p>Interactive Algorithm Exploration</p>
      </header>

      <div className="tabs">
        <button
          className={`tab-button ${activeTab === 'closest' ? 'active' : ''}`}
          onClick={() => setActiveTab('closest')}
        >
          Closest Pair Algorithm
        </button>
        <button
          className={`tab-button ${activeTab === 'karatsuba' ? 'active' : ''}`}
          onClick={() => setActiveTab('karatsuba')}
        >
          Karatsuba Multiplication
        </button>
      </div>

      <div className="tab-content">
        {activeTab === 'closest' && <ClosestPairTab />}
        {activeTab === 'karatsuba' && <KaratsubaTab />}
      </div>
    </div>
  )
}
