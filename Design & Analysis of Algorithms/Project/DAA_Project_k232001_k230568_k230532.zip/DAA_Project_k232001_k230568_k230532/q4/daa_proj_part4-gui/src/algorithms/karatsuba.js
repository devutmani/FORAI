export function karatsubaAlgorithm(x, y) {
  const log = []

  function write(msg) {
    log.push(msg + '\n')
  }

  function karatsuba(a, b, depth = 0) {
    const indent = '    '.repeat(depth)
    a = String(a)
    b = String(b)

    write(`${indent}Karatsuba(a=${a}, b=${b})`)

    if (a.length === 1 || b.length === 1) {
      const result = BigInt(a) * BigInt(b)
      write(`${indent}Base multiply ${a} * ${b} = ${result}`)
      return result
    }

    const maxLen = Math.max(a.length, b.length)
    a = a.padStart(maxLen, '0')
    b = b.padStart(maxLen, '0')

    const n = maxLen
    const half = Math.floor(n / 2)

    const aHigh = BigInt(a.substring(0, n - half))
    const aLow = BigInt(a.substring(n - half))
    const bHigh = BigInt(b.substring(0, n - half))
    const bLow = BigInt(b.substring(n - half))

    write(`${indent}Split:`)
    write(`${indent}  a_high=${aHigh}, a_low=${aLow}`)
    write(`${indent}  b_high=${bHigh}, b_low=${bLow}`)

    write(`${indent}Compute ac`)
    const ac = karatsuba(aHigh, bHigh, depth + 1)

    write(`${indent}Compute bd`)
    const bd = karatsuba(aLow, bLow, depth + 1)

    write(`${indent}Compute (a+b)(c+d)`)
    const abCd = karatsuba(aHigh + aLow, bHigh + bLow, depth + 1)

    const adPlusBc = abCd - ac - bd
    write(`${indent}ad_plus_bc = ${abCd} - ${ac} - ${bd} = ${adPlusBc}`)

    const result = ac * (BigInt(10) ** BigInt(2 * half)) + adPlusBc * (BigInt(10) ** BigInt(half)) + bd
    write(`${indent}Result = ${result}`)

    return result
  }

  write('Starting Karatsuba Integer Multiplication')
  const result = karatsuba(x, y)
  write('------------------------------------------')
  write(`FINAL RESULT = ${result}`)
  write(`Number of digits = ${String(result).length}`)

  return {
    log: log.join(''),
    result: String(result),
    digits: String(result).length,
  }
}
