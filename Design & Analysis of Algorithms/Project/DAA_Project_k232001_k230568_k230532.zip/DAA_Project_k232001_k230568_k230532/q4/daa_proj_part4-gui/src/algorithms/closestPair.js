export function closestPairAlgorithm(points) {
  const steps = []
  const log = []

  function write(msg, depth = 0) {
    log.push('    '.repeat(depth) + msg + '\n')
  }

  function addStep(step) {
    steps.push({
      ...step,
      stepNumber: steps.length,
      log: log.join(''),
    })
  }

  function dist(a, b) {
    return Math.hypot(a[0] - b[0], a[1] - b[1])
  }

  function bruteForce(arr, depth, allPoints, region = null) {
    write(`Brute force on ${arr.length} points: [${arr.map(p => `(${p[0]}, ${p[1]})`).join(', ')}]`, depth)
    
    addStep({
      type: 'brute_force_start',
      points: arr,
      allPoints,
      region,
      description: `Brute force on ${arr.length} points`,
      depth,
    })

    let best = Infinity
    let p1 = null
    let p2 = null

    for (let i = 0; i < arr.length; i++) {
      for (let j = i + 1; j < arr.length; j++) {
        const d = dist(arr[i], arr[j])
        write(
          `Compare (${arr[i][0]}, ${arr[i][1]}) with (${arr[j][0]}, ${arr[j][1]}) → ${d.toFixed(6)}`,
          depth
        )
        
        addStep({
          type: 'comparison',
          point1: arr[i],
          point2: arr[j],
          distance: d,
          allPoints,
          region,
          currentBest: best === Infinity ? null : { p1, p2, distance: best },
          description: `Comparing (${arr[i][0]}, ${arr[i][1]}) with (${arr[j][0]}, ${arr[j][1]}) → ${d.toFixed(6)}`,
          depth,
        })

        if (d < best) {
          best = d
          p1 = arr[i]
          p2 = arr[j]
          
          addStep({
            type: 'new_best',
            point1: p1,
            point2: p2,
            distance: best,
            allPoints,
            region,
            description: `New best pair found: distance = ${best.toFixed(6)}`,
            depth,
          })
        }
      }
    }

    write(
      `Brute result: (${p1[0]}, ${p1[1]}), (${p2[0]}, ${p2[1]}) dist=${best.toFixed(6)}`,
      depth
    )
    
    addStep({
      type: 'brute_force_end',
      point1: p1,
      point2: p2,
      distance: best,
      allPoints,
      region,
      description: `Brute force result: distance = ${best.toFixed(6)}`,
      depth,
    })

    return [p1, p2, best]
  }

  function solve(px, py, depth = 0, allPoints = null, parentRegion = null) {
    if (!allPoints) allPoints = px
    const n = px.length
    write(`solve() called with ${n} points`, depth)

    addStep({
      type: 'solve_start',
      points: px,
      allPoints,
      region: parentRegion,
      description: `Solving subproblem with ${n} points`,
      depth,
    })

    if (n <= 3) {
      return bruteForce(px, depth, allPoints, parentRegion)
    }

    const mid = Math.floor(n / 2)
    const midx = px[mid][0]

    const Qx = px.slice(0, mid)
    const Rx = px.slice(mid)

    const Qy = []
    const Ry = []
    const leftSet = new Set(Qx.map(p => p.join(',')))

    for (const p of py) {
      if (leftSet.has(p.join(','))) {
        Qy.push(p)
      } else {
        Ry.push(p)
      }
    }

    addStep({
      type: 'divide',
      midX: midx,
      leftPoints: Qx,
      rightPoints: Rx,
      allPoints,
      region: parentRegion,
      description: `Dividing at x = ${midx.toFixed(2)}: ${Qx.length} left, ${Rx.length} right`,
      depth,
    })

    const leftRegion = parentRegion ? {
      ...parentRegion,
      xMax: midx,
    } : { xMin: Math.min(...Qx.map(p => p[0])), xMax: midx, yMin: Math.min(...Qx.map(p => p[1])), yMax: Math.max(...Qx.map(p => p[1])) }

    const rightRegion = parentRegion ? {
      ...parentRegion,
      xMin: midx,
    } : { xMin: midx, xMax: Math.max(...Rx.map(p => p[0])), yMin: Math.min(...Rx.map(p => p[1])), yMax: Math.max(...Rx.map(p => p[1])) }

    const [p1, p2, d1] = solve(Qx, Qy, depth + 1, allPoints, leftRegion)
    const [p3, p4, d2] = solve(Rx, Ry, depth + 1, allPoints, rightRegion)

    let bestPair, d
    if (d1 < d2) {
      bestPair = [p1, p2]
      d = d1
    } else {
      bestPair = [p3, p4]
      d = d2
    }

    addStep({
      type: 'merge_start',
      leftResult: { p1, p2, distance: d1 },
      rightResult: { p1: p3, p2: p4, distance: d2 },
      currentBest: { p1: bestPair[0], p2: bestPair[1], distance: d },
      midX: midx,
      allPoints,
      description: `Merging results: left=${d1.toFixed(6)}, right=${d2.toFixed(6)}, current best=${d.toFixed(6)}`,
      depth,
    })

    const strip = py.filter(p => Math.abs(p[0] - midx) < d)

    addStep({
      type: 'strip_created',
      strip: strip,
      midX: midx,
      stripWidth: d,
      currentBest: { p1: bestPair[0], p2: bestPair[1], distance: d },
      allPoints,
      description: `Checking strip of ${strip.length} points within distance ${d.toFixed(6)} of x = ${midx.toFixed(2)}`,
      depth,
    })

    for (let i = 0; i < strip.length; i++) {
      let j = i + 1
      while (j < strip.length && strip[j][1] - strip[i][1] < d) {
        const newD = dist(strip[i], strip[j])
        
        addStep({
          type: 'strip_comparison',
          point1: strip[i],
          point2: strip[j],
          distance: newD,
          currentBest: { p1: bestPair[0], p2: bestPair[1], distance: d },
          allPoints,
          strip,
          midX: midx,
          description: `Comparing in strip: (${strip[i][0]}, ${strip[i][1]}) with (${strip[j][0]}, ${strip[j][1]}) → ${newD.toFixed(6)}`,
          depth,
        })

        if (newD < d) {
          d = newD
          bestPair = [strip[i], strip[j]]
          
          addStep({
            type: 'strip_new_best',
            point1: strip[i],
            point2: strip[j],
            distance: d,
            allPoints,
            strip,
            midX: midx,
            description: `New best from strip: distance = ${d.toFixed(6)}`,
            depth,
          })
        }
        j++
      }
    }

    addStep({
      type: 'merge_end',
      finalResult: { p1: bestPair[0], p2: bestPair[1], distance: d },
      allPoints,
      description: `Merge complete: final distance = ${d.toFixed(6)}`,
      depth,
    })

    return [bestPair[0], bestPair[1], d]
  }

  const px = [...points].sort((a, b) => a[0] - b[0])
  const py = [...points].sort((a, b) => a[1] - b[1])

  write('Starting Closest Pair Algorithm')
  addStep({
    type: 'init',
    allPoints: points,
    description: 'Starting Closest Pair Algorithm',
    depth: 0,
  })

  const [p1, p2, d] = solve(px, py, 0, points)
  write(`FINAL RESULT: (${p1[0]}, ${p1[1]}) & (${p2[0]}, ${p2[1]})  dist=${d.toFixed(6)}`)

  addStep({
    type: 'final',
    point1: p1,
    point2: p2,
    distance: d,
    allPoints: points,
    description: `FINAL RESULT: (${p1[0]}, ${p1[1]}) & (${p2[0]}, ${p2[1]})  dist=${d.toFixed(6)}`,
    depth: 0,
  })

  return {
    log: log.join(''),
    p1,
    p2,
    distance: d,
    steps,
  }
}
