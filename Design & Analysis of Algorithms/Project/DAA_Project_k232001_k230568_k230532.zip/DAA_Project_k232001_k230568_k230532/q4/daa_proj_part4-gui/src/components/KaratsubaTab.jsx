import React, { useState } from 'react'
import { karatsubaAlgorithm } from '../algorithms/karatsuba'
import '../styles/tab.css'

export default function KaratsubaTab() {
  const [x, setX] = useState('')
  const [y, setY] = useState('')
  const [log, setLog] = useState('')
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')

  const handleFileUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const lines = event.target.result
          .split('\n')
          .map(line => line.trim())
          .filter(line => line)

        if (lines.length === 1) {
          const parts = lines[0].split(/\s+/)
          if (parts.length === 2) {
            setX(parts[0])
            setY(parts[1])
          } else {
            throw new Error('Single line must have two space-separated numbers')
          }
        } else if (lines.length >= 2) {
          setX(lines[0])
          setY(lines[1])
        } else {
          throw new Error('File must contain at least one line with two numbers')
        }

        setLog('')
        setResult(null)
        setError('')
      } catch (err) {
        setError(`Error parsing file: ${err.message}`)
        setX('')
        setY('')
      }
    }
    reader.readAsText(file)
  }

  const handleRun = () => {
    if (!x || !y) {
      setError('Please enter both numbers or load a file')
      return
    }

    try {
      const { log: algLog, result: resultStr, digits } = karatsubaAlgorithm(x, y)
      setLog(algLog)
      setResult({ result: resultStr, digits })
      setError('')
    } catch (err) {
      setError(`Algorithm error: ${err.message}`)
    }
  }

  const handleClear = () => {
    setX('')
    setY('')
    setLog('')
    setResult(null)
    setError('')
  }

  return (
    <div className="tab-container">
      <div className="control-panel">
        <div className="file-input-group">
          <label htmlFor="karatsuba-file">Load Numbers File:</label>
          <input
            id="karatsuba-file"
            type="file"
            accept=".txt"
            onChange={handleFileUpload}
          />
        </div>

        <div className="input-group">
          <label htmlFor="x-input">Number 1:</label>
          <input
            id="x-input"
            type="text"
            value={x}
            onChange={(e) => setX(e.target.value)}
            placeholder="Enter first number"
          />
        </div>

        <div className="input-group">
          <label htmlFor="y-input">Number 2:</label>
          <input
            id="y-input"
            type="text"
            value={y}
            onChange={(e) => setY(e.target.value)}
            placeholder="Enter second number"
          />
        </div>

        <div className="button-group">
          <button className="btn btn-primary" onClick={handleRun} disabled={!x || !y}>
            Run Algorithm
          </button>
          <button className="btn btn-secondary" onClick={handleClear}>
            Clear All
          </button>
        </div>

        {error && <div className="error-message">{error}</div>}

        {result && (
          <div className="result-panel">
            <h3>Result</h3>
            <p className="result-value">{result.result}</p>
            <p>Digits: {result.digits}</p>
          </div>
        )}
      </div>

      <div className="content-area">
        <div className="log-container full">
          <h3>Algorithm Log</h3>
          <textarea
            readOnly
            value={log}
            className="log-output"
            placeholder="Run the algorithm to see logs here..."
          />
        </div>
      </div>
    </div>
  )
}
