import React, { useState, useEffect, useRef } from 'react'
import Plotly from 'plotly.js-dist-min'
import { closestPairAlgorithm } from '../algorithms/closestPair'
import '../styles/tab.css'

export default function ClosestPairTab() {
  const [points, setPoints] = useState([])
  const [log, setLog] = useState('')
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [steps, setSteps] = useState([])
  const [currentStep, setCurrentStep] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(1000) // milliseconds per step
  const intervalRef = useRef(null)

  const handleFileUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const lines = event.target.result.split('\n').filter(line => line.trim())
        const parsedPoints = lines.map(line => {
          const [x, y] = line.trim().split(/\s+/).map(parseFloat)
          if (isNaN(x) || isNaN(y)) throw new Error('Invalid point format')
          return [x, y]
        })

        if (parsedPoints.length < 2) throw new Error('Need at least 2 points')
        setPoints(parsedPoints)
        setLog('')
        setResult(null)
        setError('')
        setSteps([])
        setCurrentStep(0)
        setIsPlaying(false)
        if (intervalRef.current) {
          clearInterval(intervalRef.current)
          intervalRef.current = null
        }
      } catch (err) {
        setError(`Error parsing file: ${err.message}`)
        setPoints([])
      }
    }
    reader.readAsText(file)
  }

  const handleRun = () => {
    if (points.length < 2) {
      setError('Please load a file with at least 2 points')
      return
    }

    try {
      const { log: algLog, p1, p2, distance, steps: algorithmSteps } = closestPairAlgorithm(points)
      setLog(algLog)
      setResult({ p1, p2, distance })
      setSteps(algorithmSteps)
      setCurrentStep(0)
      setIsPlaying(false)
      setError('')
      if (algorithmSteps.length > 0) {
        visualizeStep(algorithmSteps[0])
      }
    } catch (err) {
      setError(`Algorithm error: ${err.message}`)
    }
  }

  const handleClear = () => {
    setPoints([])
    setLog('')
    setResult(null)
    setError('')
    setSteps([])
    setCurrentStep(0)
    setIsPlaying(false)
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
      intervalRef.current = null
    }
    const plotDiv = document.getElementById('scatter-plot')
    if (plotDiv) {
      Plotly.purge(plotDiv)
    }
  }

  useEffect(() => {
    if (isPlaying && steps.length > 0) {
      intervalRef.current = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev < steps.length - 1) {
            return prev + 1
          } else {
            setIsPlaying(false)
            return prev
          }
        })
      }, speed)
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
        intervalRef.current = null
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isPlaying, speed, steps.length])

  useEffect(() => {
    if (steps.length > 0 && currentStep < steps.length) {
      visualizeStep(steps[currentStep])
    }
  }, [currentStep, steps])

  const handlePlayPause = () => {
    if (currentStep >= steps.length - 1) {
      setCurrentStep(0)
    }
    setIsPlaying(!isPlaying)
  }

  const handleStepForward = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
      setIsPlaying(false)
    }
  }

  const handleStepBackward = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
      setIsPlaying(false)
    }
  }

  const handleReset = () => {
    setCurrentStep(0)
    setIsPlaying(false)
  }

  const handleShowFinal = () => {
    if (!steps.length) return
    setIsPlaying(false)
    setCurrentStep(steps.length - 1)
  }

  const visualizeStep = (step) => {
    if (!step || !step.allPoints) return

    const plotDiv = document.getElementById('scatter-plot')
    if (!plotDiv) return

    const traces = []
    const allXs = step.allPoints.map(p => p[0])
    const allYs = step.allPoints.map(p => p[1])

    const addPointsTrace = (pts, options) => {
      if (!pts || !pts.length) return
      traces.push({
        x: pts.map(p => p[0]),
        y: pts.map(p => p[1]),
        mode: 'markers',
        type: 'scatter',
        ...options,
      })
    }

    const addPairTrace = (point1, point2, { color = '#ffaa00', name = 'Pair', dash = 'solid', width = 2, size = 14, symbol = 'diamond', opacity = 1 } = {}) => {
      if (!point1 || !point2) return
      traces.push({
        x: [point1[0], point2[0]],
        y: [point1[1], point2[1]],
        mode: 'lines',
        type: 'scatter',
        line: { color, width, dash },
        name,
        opacity,
      })
      traces.push({
        x: [point1[0], point2[0]],
        y: [point1[1], point2[1]],
        mode: 'markers',
        type: 'scatter',
        marker: { size, color, symbol },
        name,
        opacity,
      })
    }

    const addVerticalLine = (x, { color = '#ffd700', width = 2, dash = 'dot', name = 'Partition', opacity = 1 } = {}) => {
      if (x === undefined) return
      const yMin = Math.min(...allYs)
      const yMax = Math.max(...allYs)
      traces.push({
        x: [x, x],
        y: [yMin, yMax],
        mode: 'lines',
        type: 'scatter',
        line: { color, width, dash },
        name,
        opacity,
      })
    }

    addPointsTrace(step.allPoints, {
      marker: { size: 8, color: '#4a5568', symbol: 'circle', opacity: 0.4 },
      name: 'All Points',
    })

    switch (step.type) {
      case 'divide':
        addPointsTrace(step.leftPoints, { marker: { size: 10, color: '#00d9ff' }, name: 'Left Subset' })
        addPointsTrace(step.rightPoints, { marker: { size: 10, color: '#7b61ff' }, name: 'Right Subset' })
        addVerticalLine(step.midX, { name: 'Dividing Line' })
        break
      case 'brute_force_start':
        addPointsTrace(step.points, { marker: { size: 12, color: '#00d9ff' }, name: 'Brute Points' })
        break
      case 'brute_force_end':
        addPointsTrace(step.points, { marker: { size: 12, color: '#00d9ff' }, name: 'Brute Points' })
        addPairTrace(step.point1, step.point2, { color: '#00d9ff', dash: 'dash', name: 'Best in Subset' })
        break
      case 'comparison':
      case 'new_best':
        addPairTrace(step.point1, step.point2, {
          color: step.type === 'new_best' ? '#ff0055' : '#ffaa00',
          name: step.type === 'new_best' ? 'New Best' : 'Comparing',
        })
        addPairTrace(step.currentBest?.p1, step.currentBest?.p2, {
          color: '#00d9ff',
          dash: 'dot',
          width: 1,
          size: 10,
          opacity: 0.4,
          name: 'Prev Best',
        })
        break
      case 'strip_created':
        addPointsTrace(step.strip, { marker: { size: 10, color: '#ffaa00', symbol: 'square' }, name: 'Strip Points' })
        addVerticalLine(step.midX - step.stripWidth, { color: '#ffaa00', width: 1, opacity: 0.5, name: 'Strip Boundary' })
        addVerticalLine(step.midX + step.stripWidth, { color: '#ffaa00', width: 1, opacity: 0.5, name: 'Strip Boundary' })
        addPairTrace(step.currentBest?.p1, step.currentBest?.p2, {
          color: '#00d9ff',
          dash: 'dash',
          name: 'Current Best',
        })
        break
      case 'strip_comparison':
      case 'strip_new_best':
        addPointsTrace(step.strip, { marker: { size: 10, color: '#ffaa00', symbol: 'square' }, name: 'Strip Points' })
        addPairTrace(step.point1, step.point2, {
          color: step.type === 'strip_new_best' ? '#ff0055' : '#ffaa00',
          name: step.type === 'strip_new_best' ? 'Strip Best' : 'Strip Compare',
        })
        break
      case 'merge_start':
      case 'merge_end':
        addPairTrace(step.currentBest?.p1, step.currentBest?.p2, {
          color: '#00d9ff',
          dash: 'dash',
          name: 'Current Best',
        })
        addVerticalLine(step.midX, { name: 'Dividing Line' })
        break
      case 'final':
        addPairTrace(step.point1, step.point2, { color: '#ff0055', width: 3, size: 16, name: 'Closest Pair' })
        break
      default:
        break
    }

    const layout = {
      title: {
        text: step.description || 'Closest Pair Visualization',
        font: { color: '#e0e6ed', size: 14 },
      },
      xaxis: {
        gridcolor: '#2d3748',
        zeroline: false,
        showline: true,
        linewidth: 2,
        linecolor: '#2d3748',
        mirror: true,
        tickfont: { color: '#a0aec0' },
      },
      yaxis: {
        gridcolor: '#2d3748',
        zeroline: false,
        showline: true,
        linewidth: 2,
        linecolor: '#2d3748',
        mirror: true,
        tickfont: { color: '#a0aec0' },
      },
      plot_bgcolor: '#1a1f3a',
      paper_bgcolor: '#0a0e27',
      font: { color: '#e0e6ed', family: 'monospace' },
      hovermode: 'closest',
      margin: { l: 60, r: 40, b: 60, t: 60 },
      showlegend: true,
      legend: {
        x: 1.02,
        y: 1,
        bgcolor: 'rgba(10, 14, 39, 0.8)',
        bordercolor: '#2d3748',
        borderwidth: 1,
      },
    }

    Plotly.newPlot('scatter-plot', traces, layout, { responsive: true })
  }

  return (
    <div className="tab-container">
      <div className="control-panel">
        <div className="file-input-group">
          <label htmlFor="closest-file">Load Points File:</label>
          <input
            id="closest-file"
            type="file"
            accept=".txt"
            onChange={handleFileUpload}
          />
        </div>

        {points.length > 0 && (
          <div className="file-info">
            <span>✓ Loaded {points.length} points</span>
          </div>
        )}

        <div className="button-group">
          <button className="btn btn-primary" onClick={handleRun} disabled={points.length < 2}>
            Run Algorithm
          </button>
          <button className="btn btn-secondary" onClick={handleClear}>
            Clear All
          </button>
          <button className="btn btn-secondary" onClick={handleShowFinal} disabled={steps.length === 0}>
            Final Output
          </button>
        </div>

        {steps.length > 0 && (
          <div className="animation-controls">
            <h3 style={{ fontSize: '0.85rem', color: '#00d9ff', marginBottom: '0.75rem', textTransform: 'uppercase' }}>
              Animation Controls
            </h3>
            <div className="button-group">
              <button className="btn btn-secondary" onClick={handleReset} disabled={currentStep === 0}>
                Reset
              </button>
              <button className="btn btn-secondary" onClick={handleStepBackward} disabled={currentStep === 0}>
                ← Step
              </button>
              <button className="btn btn-primary" onClick={handlePlayPause}>
                {isPlaying ? '⏸ Pause' : '▶ Play'}
              </button>
              <button className="btn btn-secondary" onClick={handleStepForward} disabled={currentStep >= steps.length - 1}>
                Step →
              </button>
            </div>
            <div className="slider-group" style={{ marginTop: '0.75rem' }}>
              <label style={{ fontSize: '0.75rem', color: '#a0aec0', marginBottom: '0.5rem', display: 'block' }}>
                Speed: {speed}ms
              </label>
              <input
                type="range"
                min="50"
                max="3000"
                step="50"
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                style={{ width: '100%' }}
              />
            </div>
            <div style={{ marginTop: '0.75rem', fontSize: '0.8rem', color: '#a0aec0' }}>
              Step {currentStep + 1} of {steps.length}
            </div>
          </div>
        )}

        {error && <div className="error-message">{error}</div>}

        {result && (
          <div className="result-panel">
            <h3>Result</h3>
            <p>
              Closest Pair: ({result.p1[0]}, {result.p1[1]}) & ({result.p2[0]}, {result.p2[1]})
            </p>
            <p>Distance: {result.distance.toFixed(6)}</p>
          </div>
        )}
      </div>

      <div className="content-area">
        <div className="plot-container">
          <div id="scatter-plot" className="plot"></div>
        </div>

        <div className="log-container">
          <h3>Algorithm Log</h3>
          <textarea
            readOnly
            value={log}
            className="log-output"
            placeholder="Run the algorithm to see logs here..."
          />
        </div>
      </div>
    </div>
  )
}
