import random
import os

os.makedirs("inputs", exist_ok=True)

sizes = [120, 150, 200, 300, 400, 600, 800, 1000, 1500, 2000]

def generate_points(filename, n_points, seed=None):
    if seed is not None:
        random.seed(seed)

    with open(filename, "w") as f:
        for _ in range(n_points):
            x = random.uniform(-1000, 1000)
            y = random.uniform(-1000, 1000)
            f.write(f"{x} {y}\n")

for i, size in enumerate(sizes, start=1):
    filename = f"inputs/points_{i}.txt"
    generate_points(filename, size, seed=100+i)
    print(f"Created {filename} with {size} points")
