import math

def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

def brute_force(points):
    n = len(points)
    if n < 2:
        return None, None, float('inf')

    best = float("inf")
    pair = (None, None)

    for i in range(n):
        for j in range(i + 1, n):
            d = dist(points[i], points[j])
            if d < best:
                best = d
                pair = (points[i], points[j])

    return pair[0], pair[1], best


def closest_pair(points):
    if len(points) < 2:
        return None, None, float("inf")

    px = sorted(points, key=lambda p: p[0])
    py = sorted(points, key=lambda p: p[1])

    def solve(px, py):
        n = len(px)
        if n <= 3:
            return brute_force(px)

        mid = n // 2
        midx = px[mid][0]

        Qx = px[:mid]
        Rx = px[mid:]

        Qy = []
        Ry = []
        qset = set(Qx)
        for p in py:
            (Qy if p in qset else Ry).append(p)

        p1, p2, d1 = solve(Qx, Qy)
        p3, p4, d2 = solve(Rx, Ry)

        d = d1
        best_pair = (p1, p2)
        if d2 < d:
            d = d2
            best_pair = (p3, p4)

        strip = [p for p in py if abs(p[0] - midx) < d]

        for i in range(len(strip)):
            j = i + 1
            while j < len(strip) and (strip[j][1] - strip[i][1]) < d:
                new_d = dist(strip[i], strip[j])
                if new_d < d:
                    d = new_d
                    best_pair = (strip[i], strip[j])
                j += 1

        return best_pair[0], best_pair[1], d

    return solve(px, py)
