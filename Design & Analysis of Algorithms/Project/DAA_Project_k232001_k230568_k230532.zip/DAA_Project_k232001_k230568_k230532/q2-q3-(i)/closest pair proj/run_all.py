import glob
import time
from closest_pair import closest_pair, brute_force

files = sorted(glob.glob("inputs/points_*.txt"))

for fname in files:
    points = []
    with open(fname) as f:
        for line in f:
            x, y = map(float, line.split())
            points.append((x, y))

    n = len(points)
    print("\n-------------------------------------")
    print(f"FILE: {fname}   Points: {n}")

    start = time.perf_counter()
    p1, p2, d = closest_pair(points)
    end = time.perf_counter()

    print(f"Closest Pair: {p1}  {p2}")
    print(f"Distance: {d}")
    print(f"Time Taken: {end - start:.6f} sec")

    if n <= 300:
        bp1, bp2, bd = brute_force(points)
        print("Brute-force verification:", "MATCHED" if abs(bd - d) < 1e-9 else "FAILED")
