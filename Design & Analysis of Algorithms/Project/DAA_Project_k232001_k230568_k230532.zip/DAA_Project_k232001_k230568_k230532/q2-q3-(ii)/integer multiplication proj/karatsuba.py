def karatsuba(x, y):
    x = str(x)
    y = str(y)

    if len(x) == 1 or len(y) == 1:
        return int(x) * int(y)

    max_len = max(len(x), len(y))
    x = x.zfill(max_len)
    y = y.zfill(max_len)

    n = max_len
    half = n // 2

    a = int(x[:n - half])
    b = int(x[n - half:])
    c = int(y[:n - half])
    d = int(y[n - half:])

    ac = karatsuba(a, c)
    bd = karatsuba(b, d)
    ad_plus_bc = karatsuba(a + b, c + d) - ac - bd

    return ac * 10**(2 * half) + ad_plus_bc * 10**half + bd


if __name__ == "__main__":
    x = "123456789"
    y = "987654321"
    print(karatsuba(x, y))
