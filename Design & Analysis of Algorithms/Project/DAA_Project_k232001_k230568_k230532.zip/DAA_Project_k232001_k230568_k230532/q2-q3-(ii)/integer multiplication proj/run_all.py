import os
from karatsuba import karatsuba

input_dir = "inputs"

for file in os.listdir(input_dir):
    if file.endswith(".txt"):
        path = os.path.join(input_dir, file)

        with open(path, "r") as f:
            x = f.readline().strip()
            y = f.readline().strip()

        print(f"\nRunning on {file}:")
        result = karatsuba(x, y)
        print("Length of result digits:", len(str(result)))
