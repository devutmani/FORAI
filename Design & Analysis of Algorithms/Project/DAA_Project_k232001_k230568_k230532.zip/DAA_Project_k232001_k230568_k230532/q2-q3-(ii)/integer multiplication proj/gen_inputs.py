import random
import os

def generate_integer(length):
    return "".join(str(random.randint(0, 9)) for _ in range(length))

os.makedirs("inputs", exist_ok=True)

for i in range(1, 10 + 1):
    n1 = generate_integer(random.randint(100, 500))
    n2 = generate_integer(random.randint(100, 500))

    with open(f"inputs/int_{i}.txt", "w") as f:
        f.write(n1 + "\n" + n2)

print("10 input files generated in /inputs/")
